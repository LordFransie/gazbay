/* 
 * ##### 965 - advanced drupal theming. #####
 *   
 * SITENAME scripts.
 * 
 */

// DUPLICATE AND UNCOMMENT
//Drupal.behaviors.behaviorName = {
//  attach: function(context) {
//    // Do some magic...
//  }
//};