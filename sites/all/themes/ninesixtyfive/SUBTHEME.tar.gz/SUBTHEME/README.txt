##### 965 - advanced drupal theming. #####

This is the root of your sub-theme.

It must contains your .info file in which you may edit many important 
settings like base theme, theme regions and additional style sheets and 
script files (http://drupal.org/node/171205).

You may edit the grid settings in your _settings.scss file in your styles folder.

Check out you theme settings page for development settings, SASS settings, Google analytics integration and more.